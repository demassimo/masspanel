#pragma once

namespace gromox {

}
