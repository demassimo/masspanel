// SPDX-License-Identifier: GPL-2.0-only WITH linking exception
// SPDX-FileCopyrightText: 2022–2026 grommunio GmbH
// This file is part of Gromox.
#include <algorithm>
#include <cassert>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <memory>
#include <gromox/proc_common.h>
#include <gromox/proptag_array.hpp>
#include <gromox/restriction.hpp>
#include <gromox/sortorder_set.hpp>
#include <gromox/util.hpp>
#include <gromox/rop_util.hpp>
#include "common_util.hpp"
#include "emsmdb_interface.hpp"
#include "exmdb_client.hpp"
#include "folder_object.hpp"
#include "message_object.hpp"
#include "processor_types.hpp"
#include "rop_ids.hpp"
#include "rop_processor.hpp"
#include "table_object.hpp"

using namespace gromox;

/**
 * @table_id:	New table id. Use 0 to unload without reassignment.
 *
 * m_loaded is cleared. The caller needs to re-assign m_loaded=true
 * if the null table was obtained from exmdb.
 */
static void table_object_set_table_id(table_object *ptable, uint32_t table_id)
{
	auto dir = ptable->plogon->get_dir();
	if (ptable->m_loaded && ptable->m_table_id != 0) {
		exmdb_client->unload_table(dir, ptable->m_table_id);
		if (ptable->rop_id == ropGetContentsTable ||
		    ptable->rop_id == ropGetHierarchyTable)
			emsmdb_interface_remove_table_notify(dir, ptable->m_table_id);
		ptable->m_loaded = false;
	}
	if (0 != table_id) {
		if (ptable->rop_id == ropGetContentsTable ||
		    ptable->rop_id == ropGetHierarchyTable)
			emsmdb_interface_add_table_notify(
				dir, table_id, ptable->handle,
				ptable->logon_id, &ptable->cxh.guid);
	}
	ptable->m_table_id = table_id;
}

ec_error_t table_object::load()
{
	auto ptable = this;
	uint32_t row_num;
	uint32_t table_id;
	uint32_t permission;
	
	if (ptable->rop_id == ropGetAttachmentTable)
		return ecSuccess;
	if (m_loaded)
		/* Already done */
		return ecSuccess;
	switch (ptable->rop_id) {
	case ropGetHierarchyTable: {
		auto username = ptable->plogon->eff_user();
		if (!exmdb_client->load_hierarchy_table(ptable->plogon->get_dir(),
		    static_cast<folder_object *>(ptable->pparent_obj)->folder_id,
		    username, ptable->table_flags, m_restriction,
		    &table_id, &row_num))
			return ecRpcFailed;
		break;
	}
	case ropGetContentsTable: {
		auto pinfo = emsmdb_interface_get_emsmdb_info();
		if (pinfo == nullptr)
			return ecError;
		auto eff_user = ptable->plogon->eff_user();
		auto rds_user = ptable->plogon->readstate_user();
		if (eff_user != STORE_OWNER_GRANTED) {
			if (ptable->plogon->is_private()) {
				if (!exmdb_client->get_folder_perm(
				    ptable->plogon->get_dir(),
				    static_cast<folder_object *>(ptable->pparent_obj)->folder_id,
				    eff_user, &permission))
					return ecRpcFailed;
				if (permission & (frightsReadAny | frightsOwner))
					rds_user = nullptr;
			}
		}
		if (!exmdb_client->load_content_table(ptable->plogon->get_dir(),
		    pinfo->cpid, static_cast<folder_object *>(ptable->pparent_obj)->folder_id,
		    rds_user, ptable->table_flags, m_restriction,
		    m_sorts, &table_id, &row_num))
			return ecRpcFailed;
		break;
	}
	case ropGetPermissionsTable:
		if (!exmdb_client->load_permission_table(ptable->plogon->get_dir(),
		    static_cast<folder_object *>(ptable->pparent_obj)->folder_id,
		    ptable->table_flags | PERMISSIONS_TABLE_FLAG_ROPFILTER,
		    &table_id, &row_num))
			return ecRpcFailed;
		break;
	case ropGetRulesTable:
		if (!exmdb_client->load_rule_table(ptable->plogon->get_dir(),
		    static_cast<folder_object *>(ptable->pparent_obj)->folder_id,
		    ptable->table_flags, m_restriction, &table_id, &row_num))
			return ecRpcFailed;
		break;
	default:
		mlog(LV_DEBUG, "%s - not calling table_object_set_table_id",
			__PRETTY_FUNCTION__);
		return ecSuccess;
	}
	/*
	 * exmdb may legitimately return a new_table_id of 0, e.g.
	 * when the folder has just been deleted.
	 */
	table_object_set_table_id(ptable, table_id);
	if (table_id == 0) {
		m_loaded = false;
		return ecObjectDeleted;
	}
	m_loaded = true;
	return ecSuccess;
}

void table_object::unload()
{
	table_object_set_table_id(this, 0);
}

ec_error_t table_object::query_rows(BOOL b_forward, uint16_t row_count,
    TARRAY_SET *pset)
{
	if (m_deleted)
		return ecObjectDeleted;
	if (!is_loaded()) {
		pset->count = 0;
		return ecSuccess;
	}
	auto ptable = this;
	
	if (!m_colset)
		return ecError;
	auto pinfo = emsmdb_interface_get_emsmdb_info();
	if (pinfo == nullptr)
		return ecError;
	if (m_position == 0 && !b_forward) {
		pset->count = 0;
		return ecSuccess;
	}
	if (m_position >= ptable->get_total() && b_forward) {
		pset->count = 0;
		return ecSuccess;
	}
	int32_t row_needed = b_forward ? row_count : -row_count; /* XXX */
	if (ptable->rop_id == ropGetAttachmentTable)
		return static_cast<message_object *>(ptable->pparent_obj)->query_attachment_table(
		       m_columns, m_position, row_needed, pset);
	return exmdb_client->query_table(ptable->plogon->get_dir(),
	       ptable->plogon->readstate_user(),
	       pinfo->cpid, m_table_id, m_columns,
	       m_position, row_needed, pset) ? ecSuccess : ecError;
}

void table_object::seek_current(BOOL b_forward, uint16_t row_count)
{
	if (m_deleted)
		return;
	assert(is_loaded());
	if (b_forward) {
		m_position += row_count;
		auto total_rows = get_total();
		if (m_position > total_rows)
			m_position = total_rows;
	} else {
		if (m_position < row_count) {
			m_position = 0;
			return;
		}
		m_position -= row_count;
	}
}

ec_error_t table_object::set_columns(proptag_cspan pcolumns) try
{
	if (m_deleted)
		return ecObjectDeleted;
	m_columns.assign(pcolumns.begin(), pcolumns.end());
	m_colset = true;
	return ecSuccess;
} catch (const std::bad_alloc &) {
	mlog(LV_ERR, "%s: ENOMEM", __PRETTY_FUNCTION__);
	return ecServerOOM;
}

ec_error_t table_object::set_sorts(const SORTORDER_SET *psorts)
{
	if (m_deleted)
		return ecObjectDeleted;
	if (m_sorts != nullptr)
		sortorder_set_free(m_sorts);
	if (NULL == psorts) {
		m_sorts = nullptr;
		return ecSuccess;
	}
	m_sorts = sortorder_set_dup(psorts);
	return m_sorts != nullptr ? ecSuccess : ecServerOOM;
}

ec_error_t table_object::set_restriction(const RESTRICTION *prestriction)
{
	if (m_deleted)
		return ecObjectDeleted;
	if (m_restriction != nullptr)
		restriction_free(m_restriction);
	if (NULL == prestriction) {
		m_restriction = nullptr;
		return ecSuccess;
	}
	m_restriction = prestriction->dup();
	return m_restriction != nullptr ? ecSuccess : ecServerOOM;
}

void table_object::set_position(uint32_t position)
{
	if (m_deleted)
		return;
	assert(is_loaded());
	auto total_rows = get_total();
	if (position > total_rows)
		position = total_rows;
	m_position = position;
}

uint32_t table_object::get_total()
{
	if (m_deleted)
		return 0;
	if (rop_id == ropGetAttachmentTable) {
		uint16_t num = 0;
		static_cast<message_object *>(pparent_obj)->get_attachments_num(&num);
		return num;
	}
	uint32_t total_rows = 0;
	exmdb_client->sum_table(plogon->get_dir(), m_table_id, &total_rows);
	return total_rows;
}

std::unique_ptr<table_object> table_object::create(logon_object *plogon,
	void *pparent_obj, uint8_t table_flags,
	uint8_t rop_id, uint8_t logon_id)
{
	std::unique_ptr<table_object> ptable;
	try {
		ptable.reset(new table_object);
	} catch (const std::bad_alloc &) {
		return NULL;
	}
	if (!emsmdb_interface_get_cxh(&ptable->cxh))
		return NULL;
	ptable->plogon = plogon;
	ptable->pparent_obj = pparent_obj;
	ptable->rop_id = rop_id;
	ptable->table_flags = table_flags;
	ptable->logon_id = logon_id;
	return ptable;
}

table_object::~table_object()
{
	auto ptable = this;
	ptable->reset();
}

ec_error_t table_object::create_bookmark(uint32_t *pindex) try
{
	if (m_deleted)
		return ecObjectDeleted;
	auto ptable = this;
	uint64_t inst_id;
	uint32_t row_type;
	uint32_t inst_num;
	
	if (!exmdb_client->mark_table(ptable->plogon->get_dir(), m_table_id,
	    m_position, &inst_id, &inst_num, &row_type))
		return ecRpcFailed;
	bookmark_list.push_back(bookmark_node{bookmark_index, row_type,
		inst_num, m_position, inst_id});
	*pindex = bookmark_index++;
	return ecSuccess;
} catch (const std::bad_alloc &) {
	mlog(LV_ERR, "%s: ENOMEM", __PRETTY_FUNCTION__);
	return ecServerOOM;
}

ec_error_t table_object::retrieve_bookmark(uint32_t index, BOOL *pb_exist)
{
	if (m_deleted)
		return ecObjectDeleted;
	assert(is_loaded());
	auto ptable = this;
	uint32_t tmp_type;
	int32_t tmp_position;
	
	auto bm = std::find_if(bookmark_list.cbegin(), bookmark_list.cend(),
	          [&](const bookmark_node &bn) { return bn.index == index; });
	if (bm == bookmark_list.end())
		return ecInvalidBookmark;
	if (!exmdb_client->locate_table(ptable->plogon->get_dir(),
	    m_table_id, bm->inst_id, bm->inst_num, &tmp_position, &tmp_type))
		return ecRpcFailed;
	*pb_exist = FALSE;
	if (tmp_position >= 0) {
		if (tmp_type == bm->row_type)
			*pb_exist = TRUE;
		m_position = tmp_position;
	} else {
		m_position = bm->position;
	}
	auto total_rows = ptable->get_total();
	if (m_position > total_rows)
		m_position = total_rows;
	return ecSuccess;
}

void table_object::remove_bookmark(uint32_t index)
{
	auto bm = std::find_if(bookmark_list.begin(), bookmark_list.end(),
	          [&](const bookmark_node &bn) { return bn.index == index; });
	if (bm != bookmark_list.end())
		bookmark_list.erase(bm);
}

void table_object::reset()
{
	auto ptable = this;
	m_columns.clear();
	m_colset = false;
	if (m_sorts != nullptr) {
		sortorder_set_free(m_sorts);
		m_sorts = nullptr;
	}
	if (m_restriction != nullptr) {
		restriction_free(m_restriction);
		m_restriction = nullptr;
	}
	m_position = 0;
	table_object_set_table_id(ptable, 0);
	ptable->clear_bookmarks();
}

ec_error_t table_object::get_all_columns(PROPTAG_ARRAY *pcolumns) const
{
	auto ptable = this;
	if (ptable->rop_id == ropGetAttachmentTable)
		return static_cast<message_object *>(ptable->pparent_obj)->
		       get_attachment_table_all_proptags(pcolumns);
	return exmdb_client->get_table_all_proptags(ptable->plogon->get_dir(),
	       m_table_id, pcolumns) ? ecSuccess : ecRpcFailed;
}

ec_error_t table_object::match_row(BOOL b_forward, const RESTRICTION *pres,
    int32_t *pposition, TPROPVAL_ARRAY *ppropvals) const
{
	if (m_deleted)
		return ecObjectDeleted;
	auto ptable = this;
	if (!m_colset)
		return ecError;
	auto pinfo = emsmdb_interface_get_emsmdb_info();
	return exmdb_client->match_table(ptable->plogon->get_dir(),
	       ptable->plogon->readstate_user(),
	       pinfo->cpid, m_table_id, b_forward, m_position,
	       pres, m_columns, pposition, ppropvals) ? ecSuccess : ecRpcFailed;
}

ec_error_t table_object::read_row(uint64_t inst_id, uint32_t inst_num,
    TPROPVAL_ARRAY *ppropvals) const
{
	if (m_deleted)
		return ecObjectDeleted;
	auto ptable = this;
	if (!m_colset)
		return ecError;
	auto pinfo = emsmdb_interface_get_emsmdb_info();
	return exmdb_client->read_table_row(ptable->plogon->get_dir(),
	       ptable->plogon->readstate_user(),
	       pinfo->cpid, m_table_id, m_columns,
	       inst_id, inst_num, ppropvals) ? ecSuccess : ecRpcFailed;
}

ec_error_t table_object::expand(uint64_t inst_id,
    int32_t *pposition, uint32_t *prow_count) const
{
	if (m_deleted)
		return ecObjectDeleted;
	BOOL found = false;
	if (!exmdb_client->expand_table(plogon->get_dir(),
	    m_table_id, inst_id, &found, pposition, prow_count))
		return ecRpcFailed;
	if (!found)
		return ecNotFound;
	if (*pposition < 0)
		return ecNotCollapsed;
	return ecSuccess;
}

ec_error_t table_object::collapse(uint64_t inst_id,
    int32_t *pposition, uint32_t *prow_count) const
{
	if (m_deleted)
		return ecObjectDeleted;
	BOOL found = false;
	if (!exmdb_client->collapse_table(plogon->get_dir(),
	    m_table_id, inst_id, &found, pposition, prow_count))
		return ecRpcFailed;
	if (!found)
		return ecNotFound;
	if (*pposition < 0)
		return ecNotExpanded;
	return ecSuccess;
}

ec_error_t table_object::store_state(uint64_t inst_id, uint32_t inst_num,
    uint32_t *pstate_id) const
{
	if (m_deleted)
		return ecObjectDeleted;
	return exmdb_client->store_table_state(plogon->get_dir(),
	       m_table_id, inst_id, inst_num, pstate_id) ?
	       ecSuccess : ecRpcFailed;
}

ec_error_t table_object::restore_state(uint32_t state_id, uint32_t *pindex)
{
	if (m_deleted)
		return ecObjectDeleted;
	int32_t position;
	uint64_t inst_id;
	uint32_t inst_num;
	uint32_t tmp_type;
	uint32_t new_position;
	auto ptable = this;
	
	if (!exmdb_client->mark_table(ptable->plogon->get_dir(),
	    m_table_id, m_position, &inst_id, &inst_num, &tmp_type))
		return ecRpcFailed;
	if (!exmdb_client->restore_table_state(ptable->plogon->get_dir(),
	    m_table_id, state_id, &position))
		return ecRpcFailed;	
	if (!exmdb_client->locate_table(ptable->plogon->get_dir(),
	    m_table_id, inst_id, inst_num,
	    reinterpret_cast<int32_t *>(&new_position), &tmp_type))
		return ecRpcFailed;
	if (position < 0) {
		/* assign an invalid bookmark index */
		*pindex = ptable->bookmark_index++;
		return ecSuccess;
	}
	m_position = position;
	auto err = ptable->create_bookmark(pindex);
	if (err != ecSuccess) {
		m_position = new_position;
		return err;
	}
	m_position = new_position;
	return ecSuccess;
}
