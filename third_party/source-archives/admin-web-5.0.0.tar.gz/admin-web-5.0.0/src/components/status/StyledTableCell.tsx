// SPDX-License-Identifier: AGPL-3.0-or-later
// SPDX-FileCopyrightText: 2020-2026 grommunio GmbH

import { TableCell } from '@mui/material';
import { withStyles } from 'tss-react/mui';

const StyledTableCell = withStyles(TableCell, theme => ({
  head: {
    backgroundColor: theme.palette.primary.light,
    border: '1px solid white',
    color: 'black',
  },
}));

export default StyledTableCell;