// SPDX-License-Identifier: AGPL-3.0-or-later
// SPDX-FileCopyrightText: 2020-2026 grommunio GmbH

import React, { useContext, useRef, useState } from 'react';
import { Paper, Tabs, Tab, Theme } from '@mui/material';
import { deleteFolderData, fetchFolderTree } from '../actions/folders';
import AddFolder from '../components/Dialogs/AddFolder';
import { DOMAIN_ADMIN_WRITE } from '../constants';
import { CapabilityContext } from '../CapabilityContext';
import TableViewContainer from '../components/TableViewContainer';
import DeleteFolder from '../components/Dialogs/DeleteFolder';
import SearchTextfield from '../components/SearchTextfield';
import Tree from 'react-d3-tree';
import FolderHierarchy from '../components/FolderHierarchy';
import TableActionGrid from '../components/TableActionGrid';
import { AccountTree, List } from '@mui/icons-material';
import { useNavigate } from 'react-router';
import { makeStyles } from 'tss-react/mui';
import { useTranslation } from 'react-i18next';
import { useAppDispatch, useAppSelector } from '../store';
import { ChangeEvent, DomainViewProps } from '@/types/common';
import { URLParams } from '@/actions/types';
import { useTable } from '../hooks/useTable';
import { Folder } from '@/types/folders';


const useStyles = makeStyles()((theme: Theme) => ({
  tablePaper: {
    margin: theme.spacing(1, 2, 3, 2),
    borderRadius: 6,
  },
  circularProgress: {
    margin: theme.spacing(1, 0, 1, 0),
  },
  count: {
    margin: theme.spacing(2, 0, 0, 2),
  },
  breadcumbs: {
    margin: theme.spacing(3, 0, 0, 2),
  },
  link: {
    cursor: 'pointer',
  },
  tabs: {
    marginLeft: 16,
  },
  treeContainer: {
    height: '100%',
    display: 'flex',
    stroke: theme.palette.primary.main,
  },
  treeNodeLabel: {
    fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", "Roboto", "Oxygen", "Ubuntu", "Cantarell", "Fira Sans", "Droid Sans", "Helvetica Neue", sans-serif',
    fontWeight: 'lighter',
    stroke: theme.palette.mode === 'dark' ? 'white' : 'black',
  },
  treeNode: {
    stroke: theme.palette.primary.main,
  },
}));

type RenderNodeProps = {
  nodeDatum: {
    name: string;
    folderid: string;
  },
  toggleNode: () => void;
}

interface FoldersState {
  offset: number;
  tab: number;
  root: number;
  adding: string;
  filteredTree: Folder | null;
}

const Folders = ({ domain }: DomainViewProps) => {
  const { classes } = useStyles();
  const { t } = useTranslation();
  const dispatch = useAppDispatch();
  const { folders } = useAppSelector(state => state);
  const [state, setState] = useState<FoldersState>({
    offset: 0,
    tab: 0,
    root: -1,
    adding: "",
    filteredTree: null,
  });
  const context = useContext(CapabilityContext);
  const treeContainer = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();

  const fetchTableData = async (params: URLParams) => 
    await dispatch(fetchFolderTree(domain.ID, params));
  const deleteItem = async (domainID: number, id: string, params: { clear: boolean }) =>
    await dispatch(deleteFolderData(domainID, id, params));

  const table = useTable({
    fetchTableData,
    defaultState: { orderBy: 'displayname' },
  });

  const {
    tableState,
    clearSnackbar,
    handleAddingError,
    handleDelete,
    handleDeleteClose,
    handleDeleteError,
    handleDeleteSuccess,
    handleEdit,
  } = table;

  const handleTab = (_: unknown, tab: number) => setState({ ...state, tab });

  const renderNode = ({ nodeDatum, toggleNode }: RenderNodeProps) => {
    return <g onClick={handleNodeClicked(nodeDatum?.folderid)}>
      <rect className={classes.treeNode} width="20" height="20" x="-10" onClick={toggleNode} />
      <text className={classes.treeNodeLabel} strokeWidth="1" x="20" y="15">
        {nodeDatum?.name}
      </text>
    </g>;
  }

  const getOffset = () => {
    const container = treeContainer.current;
    return {
      x: container ? ((container.clientWidth - 32) /* padding */) / 2 : 0,
      y: 50,
    };
  }

  const handleNodeClicked = (id: string) => () => {
    navigate('/' + domain.ID + '/folders/' + id);
  }

  const handleAdd = (parentID: string) => (e: React.MouseEvent) => {
    e.stopPropagation();
    setState({ ...state, adding: parentID });
  }

  const handleAddingClose = () => {
    setState({ ...state, adding: "" });
  }

  const handleAddingSuccess = () => {
    handleAddingSuccess();
    setState({ ...state, adding: "" });
  }

  const handleMatch = (e: ChangeEvent) => {
    const { value } = e.target;
    const Tree = structuredClone(folders.Tree);
    const filteredTree = prune(Tree, value);
    setState({ ...state, filteredTree });
  }

  // Recursive tree filter
  const prune = (node: Folder, text: string) => {
    const children: Folder[] = [];
    node.children?.forEach(child => {
      if(prune(child, text)) {
        children.push(child);
      }
    });
    node.children = children;
    return node.children.length > 0 || node["name"].includes(text) ? node : null;
  }


  const writable = context.includes(DOMAIN_ADMIN_WRITE);
  const { loading, snackbar, deleting } = tableState;
  const { adding, tab, filteredTree } = state;

  return (
    <TableViewContainer
      headline={t("Folders")}
      subtitle={t('folders_sub')}
      href="https://docs.grommunio.com/admin/administration.html#folders"
      snackbar={snackbar}
      onSnackbarClose={clearSnackbar}
      baseRef={treeContainer}
      loading={loading}
    >
      <TableActionGrid
        tf={<SearchTextfield
          onChange={handleMatch}
          placeholder={t("Search folders")}
        />}
      >
        <Tabs
          indicatorColor="primary"
          textColor="primary"
          className={classes.tabs}
          onChange={handleTab}
          value={tab}
        >
          <Tab sx={{ minHeight: 48 }} label={t("List")} iconPosition='start' icon={<List />}/>
          <Tab sx={{ minHeight: 48 }} label={t("Tree")} iconPosition='start' icon={<AccountTree />}/>
        </Tabs>
      </TableActionGrid>
      {!tab && 
        <Paper className={classes.tablePaper} elevation={1}>
          <FolderHierarchy
            domainID={domain.ID}
            data={filteredTree || folders.Tree}
            handleAdd={handleAdd}
            handleEdit={handleEdit}
            handleDelete={handleDelete}
            writable={writable}
          />
        </Paper>}
      {tab === 1 && 
        <div className={classes.treeContainer}>
          <Paper style={{ flex: 1 }}>
            <Tree
              data={folders.Tree}
              orientation="vertical"
              renderCustomNodeElement={renderNode as any}
              depthFactor={50}
              pathFunc="step"
              translate={getOffset()}
              scaleExtent={{
                min: 0.1,
                max: 2,
              }}
              separation={{
                siblings: 2,
                nonSiblings: 2,
              }}
              collapsible={false}
            />
          </Paper>
        </div>}
      <AddFolder
        open={!!adding}
        onClose={handleAddingClose}
        onSuccess={handleAddingSuccess}
        onError={handleAddingError}
        domain={domain}
        parentID={adding}
      />
      <DeleteFolder
        open={!!deleting}
        delete={deleteItem}
        onSuccess={handleDeleteSuccess}
        onError={handleDeleteError}
        onClose={handleDeleteClose}
        item={deleting.displayname}
        id={deleting.folderid}
        domainID={domain.ID}
      />
    </TableViewContainer>
  );
}


export default Folders;
