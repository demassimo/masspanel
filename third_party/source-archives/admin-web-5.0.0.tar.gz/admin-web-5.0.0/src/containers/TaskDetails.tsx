// SPDX-License-Identifier: AGPL-3.0-or-later
// SPDX-FileCopyrightText: 2020-2026 grommunio GmbH

import React, { useEffect, useState } from 'react';
import { makeStyles } from 'tss-react/mui';
import { useTranslation } from 'react-i18next';
import {
  Typography,
  Paper,
  Grid2,
  Button,
  Divider,
  Tooltip,
  IconButton,
  Theme,
} from '@mui/material';
import { getStringAfterLastSlash, getTaskState, setDateTimeString } from '../utils';
import Feedback from '../components/Feedback';
import ViewWrapper from '../components/ViewWrapper';
import { cancelTask, deleteTask, fetchTaskDetails } from '../actions/taskq';
import { green, red } from '@mui/material/colors';
import { CancelOutlined, Delete, Refresh } from '@mui/icons-material';
import { useNavigate } from 'react-router';
import { useAppDispatch } from '../store';
import { TaskParam } from '@/types/tasks';


const useStyles = makeStyles()((theme: Theme) => ({
  paper: {
    margin: theme.spacing(3, 2, 3, 2),
    padding: theme.spacing(2, 2, 2, 2),
    borderRadius: 6,
  },
  description: {
    display: 'inline-block',
    fontWeight: 500,
    minWidth: 240,
  },
  params: {
    padding: '16px 0 8px 0',
  },
  param: {
    padding: '4px 16px',
  },
  resultParam: {
    padding: '4px 8px 4px 0px',
  },
  container: {
    margin: theme.spacing(0, 2, 2, 2),
  },
  flexRow: {
    padding: '4px 0px',
    display: 'flex',
  },
  centerRow: {
    display: 'flex',
    alignItems: 'center',
  },
}));

const TaskDetails = () => {
  const { classes } = useStyles();
  const { t } = useTranslation();
  const dispatch = useAppDispatch();
  const [task, setTask] = useState({
    ID: -1,
    command: '',
    state: 0,
    created: null,
    updated: null,
    message: '',
    params: {} as Record<string, TaskParam[]>,
    loading: false,
    snackbar: "",
  });
  const navigate = useNavigate();

  useEffect(() => {
    refresh();
  }, []);

  const refresh = async () => {
    setTask({ ...task, loading: true });
    const taskData = await dispatch(fetchTaskDetails(parseInt(getStringAfterLastSlash())))
      .catch(message => setTask({ ...task, snackbar: message || 'Unknown error' }));
    setTask({
      ...task, 
      loading: false,
      ...(taskData ? {
        ...taskData,
        params: taskData.params || {},
      } : {})
    });
  }

  const handleDelete = () => {
    dispatch(deleteTask(task.ID))
      .then(() => navigate("/taskq"))
      .catch(message => setTask({ ...task, snackbar: message || 'Unknown error' }));
  }

  const handleCancel= () => {
    dispatch(cancelTask(task.ID))
      .then(refresh)
      .catch(message => setTask({ ...task, snackbar: message || 'Unknown error' }));
  }

  const handleNavigation = (path: string) => (event: React.MouseEvent) => {
    event.preventDefault();
    navigate(`/${path}`);
  }

  const { loading, snackbar, ID, command, state, created, updated, message, params } = task;

  return (
    <ViewWrapper
      snackbar={snackbar}
      onSnackbarClose={() => setTask({ ...task, snackbar: '' })}
      loading={loading}
    >
      <Paper className={classes.paper} elevation={1}>
        <Grid2 container direction="column" className={classes.container}>
          <div className={classes.centerRow}>
            <Typography variant='h6' className={classes.description}>{t('Task ID')}:</Typography>
            {ID || t('Unknown')}
          </div>
          <div className={classes.centerRow}>
            <Typography variant='h6' className={classes.description}>{t('Command')}:</Typography>
            {command || t('Unknown')}
          </div>
          <div className={classes.centerRow}>
            <Typography variant='h6' className={classes.description}>{t('State ')}:</Typography>
            {t(getTaskState(state)) || t('Unknown')}
            <IconButton onClick={refresh}>
              <Refresh color="primary"/>
            </IconButton>
            <IconButton onClick={handleCancel}>
              <CancelOutlined color="error"/>
            </IconButton>
            <IconButton onClick={handleDelete}>
              <Delete color="error"/>
            </IconButton>
          </div>
          <div className={classes.centerRow}>
            <Typography variant='h6' className={classes.description}>{t('Message')}:</Typography>
            {message || t('Unknown')}
          </div>
          <div className={classes.centerRow}>
            <Typography variant='h6' className={classes.description}>{t('Created')}:</Typography>
            {setDateTimeString(created) || t('Unknown')}
          </div>
          <div className={classes.centerRow}>
            <Typography variant='h6' className={classes.description}>{t('Updated')}:</Typography>
            {setDateTimeString(updated) || t('Unknown')}
          </div>
            
          <Divider style={{ marginTop: 8 }}/>
          <Typography variant="h6" className={classes.params}>
            {t('Params')}
          </Typography>
          {Object.entries(params).map(([param, value], key) => {
            const displayValue = JSON.stringify(value);
            return param !== 'result' ? <div className={classes.centerRow} key={key}>
              <Typography className={classes.description}>{param}:</Typography>
              {displayValue || t('Unknown')}
            </div> :
              <div className={classes.flexRow} key={key}>
                <div className={classes.description}>{param}</div>
                <div>
                  {(value || []).map(({username, code, message}, idx) =>
                    <Tooltip key={idx} placement='right' title={message || ''}>
                      <Typography className={classes.resultParam}>
                        <span
                          style={{
                            marginRight: 8,
                            backgroundColor: code < 300 /* code 2xx */ ? green['500'] : red['500'],
                            borderRadius: 4,
                            padding: '2px 4px',
                          }}
                        >
                          {code}
                        </span>
                        {username}
                      </Typography>
                    </Tooltip>
                  )}
                </div>
              </div>;
          })}
        </Grid2>
        <Button
          color="secondary"
          onClick={handleNavigation('taskq')}
        >
          {t('Back')}
        </Button>
      </Paper>
      <Feedback
        snackbar={snackbar}
        onClose={() => setTask({ ...task, snackbar: '' })}
      />
    </ViewWrapper>
  );
}


export default TaskDetails;
