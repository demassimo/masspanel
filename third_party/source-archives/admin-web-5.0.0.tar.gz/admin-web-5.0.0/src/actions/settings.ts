// SPDX-License-Identifier: AGPL-3.0-or-later
// SPDX-FileCopyrightText: 2020-2026 grommunio GmbH

import {
  CHANGE_SETTINGS,
} from './types';

export function changeSettings(field: string, value: string | number | boolean) {
  return { type: CHANGE_SETTINGS, field, value };
}