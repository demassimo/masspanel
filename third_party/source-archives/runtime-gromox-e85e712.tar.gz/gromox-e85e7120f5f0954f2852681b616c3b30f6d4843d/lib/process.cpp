// SPDX-License-Identifier: AGPL-3.0-or-later
// SPDX-FileCopyrightText: 2022–2026 grommunio GmbH
// This file is part of Gromox.
#define _GNU_SOURCE 1 /* linux: gettid */
#ifdef HAVE_CONFIG_H
#	include "config.h"
#endif
#include <algorithm>
#include <any>
#include <cassert>
#include <cerrno>
#include <csignal>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <fcntl.h>
#include <memory>
#include <mutex>
#include <pthread.h>
#include <sched.h>
#include <spawn.h>
#include <string>
#include <thread>
#include <unistd.h>
#ifdef __GNUC__
#	include <cxxabi.h>
#endif
#ifdef __GLIBC__
#	include <execinfo.h>
#	include <malloc.h>
#endif
#include <netinet/in.h>
#if defined(__linux__) && defined(__GLIBC__) && __GLIBC__ == 2 && __GLIBC_MINOR__ >= 30
#	define HAVE_GLIBC_GETTID 1
#endif
#ifdef HAVE_SYS_EPOLL_H
#	include <sys/epoll.h>
#endif
#ifdef HAVE_SYS_EVENT_H
#	include <sys/event.h>
#endif
#include <sys/resource.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/un.h>
#include <sys/wait.h>
#ifdef __sun
#	include <sys/lwp.h>
#endif
#ifndef HAVE_GLIBC_GETTID
#	include <sys/syscall.h>
#endif
#ifdef __FreeBSD__
#	include <sys/sysctl.h>
#	include <sys/thr.h>
#	include <sys/types.h>
#endif
#include <libHX/endian.h>
#include <libHX/io.h>
#include <libHX/proc.h>
#include <libHX/scope.hpp>
#include <libHX/socket.h>
#include <libHX/string.h>
#include <gromox/clock.hpp>
#include <gromox/fileio.h>
#include <gromox/generic_connection.hpp>
#include <gromox/listener_ctx.hpp>
#include <gromox/poll_ctx.hpp>
#include <gromox/process.hpp>
#include <gromox/socketpass.hpp>
#include <gromox/util.hpp>
#include <gromox/workqueue.hpp>

using namespace gromox;

extern "C" {
extern char **environ;
}

namespace gromox {

static int gx_reexec_top_fd = -1;
workqueue global_workqueue;

errno_t filedes_limit_bump(size_t max)
{
	struct rlimit rl;
	if (getrlimit(RLIMIT_NOFILE, &rl) != 0) {
		int se = errno;
		mlog(LV_ERR, "getrlimit: %s", strerror(se));
		return se;
	}
	if (max == 0)
		max = rl.rlim_max;
	if (static_cast<size_t>(rl.rlim_cur) < max) {
		rl.rlim_cur = max;
		rl.rlim_max = max;
		if (setrlimit(RLIMIT_NOFILE, &rl) != 0) {
			int se = errno;
			mlog(LV_WARN, "setrlimit RLIMIT_NOFILE %zu: %s",
				max, strerror(se));
			return se;
		}
	}
	if (getrlimit(RLIMIT_NOFILE, &rl) != 0) {
		int se = errno;
		mlog(LV_ERR, "getrlimit: %s", strerror(se));
		return se;
	}
	mlog(LV_NOTICE, "system: maximum file descriptors: %zu",
		static_cast<size_t>(rl.rlim_cur));
	return 0;
}

/**
 * Hand free top-of-arena pages back to the OS. glibc only trims the main arena
 * automatically; the per-thread arenas it spins up under concurrency keep
 * their freed pages mapped, so RSS otherwise stays at the high-water of the
 * busiest burst (reusable, not leaked, but resident) until the process exits.
 */
heap_reaper::heap_reaper(unsigned int sec)
{
	/* this function has to die */
#ifdef __GLIBC__
	if (sec == 0)
		return;
	auto ret = global_workqueue.insert_task("heap_reaper",
	           std::chrono::seconds(sec), [](std::any &) { malloc_trim(0); });
	if (ret != 0)
		mlog(LV_WARN, "cannot start heap reaper task: %s", strerror(ret));
#endif
}

heap_reaper::~heap_reaper()
{
#ifdef __GLIBC__
	global_workqueue.delete_task("heap_reaper");
#endif
}

/**
 * Give an approximate limit of how many threads make sense to run under the
 * current conditions.
 */
unsigned int gx_concurrency()
{
#if defined(__linux__) && defined(__GLIBC__)
	cpu_set_t set;
	CPU_ZERO_S(sizeof(set), &set);
	if (sched_getaffinity(0, sizeof(set), &set) == 0)
		return CPU_COUNT_S(sizeof(set), &set);
#endif
	return std::thread::hardware_concurrency();
}

unsigned long gx_gettid()
{
#ifdef HAVE_GLIBC_GETTID
	return gettid();
#elif defined(__linux__)
	return syscall(SYS_gettid);
#elif defined(__OpenBSD__)
	return getthrid();
#elif defined(__FreeBSD__)
	long z = 0;
	return thr_self(&z) == 0 ? z : (unsigned long)pthread_self();
#elif defined(__sun)
	return _lwp_self();
#else
	return (unsigned long)pthread_self();
#endif
}

/**
 * Upon setuid, tasks are restricted in their dumping (cf. linux/kernel/cred.c
 * in commit_creds, calling set_dumpable). To restore the dump flag, one could
 * use prctl, but re-executing the process has the benefit that the application
 * completely re-runs as unprivileged user from the start and can catch e.g.
 * file access errors that would occur before gx_reexec, and we can be sure
 * that privileged informationed does not escape into a dump.
 */
static errno_t gx_reexec(const char *const *argv) try
{
	auto s = getenv("GX_REEXEC_DONE");
	if (s != nullptr || argv == nullptr) {
		if (chdir("/") < 0)
			mlog(LV_ERR, "E-5312: chdir /: %s", strerror(errno));
		unsetenv("GX_REEXEC_DONE");
		unsetenv("HX_LISTEN_TOP_FD");
		unsetenv("LISTEN_FDS");
		return 0;
	}
	if (gx_reexec_top_fd >= 0)
		setenv("HX_LISTEN_TOP_FD", std::to_string(gx_reexec_top_fd + 1).c_str(), true);
	setenv("GX_REEXEC_DONE", "1", true);

#if defined(__linux__)
	hxmc_t *resolved = nullptr;
	auto ret = HX_readlink(&resolved, "/proc/self/exe");
	if (ret == -ENOENT) {
		mlog(LV_NOTICE, "reexec: readlink /proc/self/exe: %s; continuing without reexec-after-setuid, coredumps may be disabled", strerror(-ret));
		return 0;
	} else if (ret < 0) {
		mlog(LV_ERR, "reexec: readlink /proc/self/exe: %s", strerror(-ret));
		return -ret;
	}
	mlog(LV_INFO, "Reexecing %s", resolved);
	execv(resolved, const_cast<char **>(argv));
	int saved_errno = errno;
	perror("execv");
	HXmc_free(resolved);
	return saved_errno;
#elif defined(__FreeBSD__)
	std::string tgt;
	tgt.resize(64);
	int oid[] = {CTL_KERN, KERN_PROC, KERN_PROC_PATHNAME, -1};
	while (true) {
		size_t z = tgt.size();
		auto ret = sysctl(oid, std::size(oid), tgt.data(), &z,
		           nullptr, 0);
		if (ret == 0) {
			tgt.resize(z);
			break;
		}
		if (errno != ENOMEM)
			return errno;
		tgt.resize(tgt.size() * 2);
	}
	mlog(LV_INFO, "Reexecing %s", tgt.c_str());
	execv(tgt.c_str(), const_cast<char **>(argv));
	int saved_errno = errno;
	perror("execv");
	return saved_errno;
#else
	/* Since none of our programs modify argv[0], executing the same should just work */
	mlog(LV_INFO, "Reexecing %s", argv[0]);
	execv(argv[0], const_cast<char **>(argv));
	int saved_errno = errno;
	perror("execv");
	return saved_errno;
#endif
} catch (const std::bad_alloc &) {
	return ENOMEM;
}

/**
 * Prepare a file descriptor so that it survives execve().
 * Sets a new upper bound on file descriptor numbers that need to be evaluated
 * on the next incarnation of the process.
 */
void gx_reexec_record(int new_fd)
{
	if (getenv("GX_REEXEC_DONE") != nullptr)
		return;
	for (int fd = gx_reexec_top_fd; fd <= new_fd; ++fd) {
		unsigned int flags = 0;
		socklen_t fz = sizeof(flags);
		if (fd < 0 || getsockopt(fd, SOL_SOCKET, SO_ACCEPTCONN,
		    &flags, &fz) != 0 || !flags)
			continue;
		flags = fcntl(fd, F_GETFD, 0) & ~FD_CLOEXEC;
		if (fcntl(fd, F_SETFD, flags) != 0)
			/* ignore */;
	}
	if (new_fd > gx_reexec_top_fd)
		gx_reexec_top_fd = new_fd;
}

/**
 * Start new thread with a big 16MB stack. Needed until high
 * consumers (gcc -fstack-usage) are eradicated.
 */
int pthread_create4(pthread_t *t, std::nullptr_t, void *(*f)(void *), void *a) noexcept
{
	pthread_attr_t attr;
	pthread_attr_init(&attr);
	size_t tss = 0;
	auto ret = pthread_attr_getstacksize(&attr, &tss);
	if (ret == 0)
		tss = std::max(tss, static_cast<size_t>(16UL << 20));
	ret = pthread_attr_setstacksize(&attr, tss);
	if (ret != 0) {
		mlog(LV_ERR, "E-1135: pthread_attr_setstacksize: %s", strerror(ret));
		pthread_attr_destroy(&attr);
		return ret;
	}
	ret = pthread_create(t, &attr, f, a);
	pthread_attr_destroy(&attr);
	return ret;
}

/**
 * Make a few common signals non-fatal.
 */
int setup_signal_defaults()
{
	static int tab[] = {SIGALRM, SIGUSR1, SIGUSR2};
	for (auto signum : tab) {
		struct sigaction act;
		auto ret = sigaction(signum, nullptr, &act);
		if (ret < 0 || act.sa_handler != SIG_DFL)
			continue;
		sigemptyset(&act.sa_mask);
		act.sa_handler = [](int) {};
		ret = sigaction(signum, &act, nullptr);
		if (ret != 0)
			mlog(LV_ERR, "sigaction (%u): %s", signum, strerror(errno));
	}
	return 0;
}

std::string simple_backtrace()
{
	std::string out;
	/* Tried ILT's libbacktrace, but in practice it takes 500 ms per backtrace */
#ifdef __GLIBC__
	void *frame_ptrs[128];
	int num = backtrace(frame_ptrs, std::size(frame_ptrs));
	if (num == 0)
		return out;
	std::unique_ptr<char *[], stdlib_delete> names(backtrace_symbols(frame_ptrs, num));
	if (names == nullptr)
		return out;
	try {
		/* Frame 0 is simple_backtrace itself, skip it */
		for (int i = 1; i < num; ++i)
			out += std::string("<") + znul(HX_basename(names[i])) + ">";
	} catch (...) {
	}
#endif
	return out;
}

errno_t switch_user_exec(const char *user, char *const *argv)
{
	if (user == nullptr)
		user = RUNNING_IDENTITY;
	auto su_ret = HXproc_switch_user(user, nullptr);
	int se = errno;
	switch (su_ret) {
	case HXPROC_SU_NOOP: {
		auto ret = gx_reexec(nullptr);
		if (ret != 0)
			return ret;
		auto m = umask(07777);
		m = (m & ~0070) | ((m & 0700) >> 3); /* copy user bits to group bits */
		umask(m);
		return 0;
	}
	case HXPROC_SU_SUCCESS: {
		auto ret = gx_reexec(const_cast<const char *const *>(argv));
		if (ret != 0)
			return ret;
		auto m = umask(07777);
		m = (m & ~0070) | ((m & 0700) >> 3);
		umask(m);
		return 0;
	}
	case HXPROC_USER_NOT_FOUND:
		mlog(LV_ERR, "No such user \"%s\": %s", user, strerror(se));
		break;
	case HXPROC_GROUP_NOT_FOUND:
		mlog(LV_ERR, "Group lookup failed/Can't happen");
		break;
	case HXPROC_SETUID_FAILED:
		mlog(LV_ERR, "setuid to \"%s\" failed: %s", user, strerror(se));
		break;
	case HXPROC_SETGID_FAILED:
		mlog(LV_ERR, "setgid to groupof(\"%s\") failed: %s", user, strerror(se));
		break;
	case HXPROC_INITGROUPS_FAILED:
		mlog(LV_ERR, "initgroups for \"%s\" failed: %s", user, strerror(se));
		break;
	}
	return se;
}

poll_ctx::~poll_ctx()
{
	if (m_epfd >= 0)
		close(m_epfd);
}

void poll_ctx::reset()
{
	if (m_epfd >= 0) {
		close(m_epfd);
		m_epfd = -1;
	}
	m_events = {};
}

errno_t poll_ctx::init(int max_ev)
{
	if (m_epfd >= 0) {
		close(m_epfd);
		m_epfd = -1;
	}
	try {
#ifdef HAVE_SYS_EPOLL_H
		m_events.resize(max_ev);
#elif defined(HAVE_SYS_EVENT_H)
		/* READ-ready and WRITE-ready seems to be separately notified */
		m_events.resize(max_ev * 2);
#endif
	} catch (const std::bad_alloc &) {
		mlog(LV_ERR, "%s: ENOMEM", __PRETTY_FUNCTION__);
		return ENOMEM;
	}
#ifdef HAVE_SYS_EPOLL_H
	m_epfd = epoll_create1(EPOLL_CLOEXEC);
	if (m_epfd < 0) {
		errno_t se = errno;
		mlog(LV_ERR, "poll_ctx::setup: epoll_create: %s", strerror(se));
		return se;
	}
#elif defined(HAVE_SYS_EVENT_H)
	m_epfd = kqueue();
	if (m_epfd < 0) {
		errno_t se = errno;
		mlog(LV_ERR, "poll_ctx::setup: kqueue: %s", strerror(se));
		return se;
	}
#endif
	return 0;
}

errno_t poll_ctx::addmod(unsigned int mask, int fd, void *ctx, bool add)
{
#ifdef HAVE_SYS_EPOLL_H
	struct epoll_event ev{};
	ev.data.ptr = ctx;
	if (mask & polling_read)
		ev.events |= EPOLLIN;
	if (mask & polling_write)
		ev.events |= EPOLLOUT;
	if (!(mask & level_trigger))
		ev.events |= EPOLLET | EPOLLONESHOT;
	auto ret = epoll_ctl(m_epfd, add ? EPOLL_CTL_ADD : EPOLL_CTL_MOD, fd, &ev);
#elif defined(HAVE_SYS_EVENT_H)
	unsigned int flags = (mask & level_trigger) ? EV_CLEAR : EV_ONESHOT;
	struct kevent ev[2]{};
	ev[0].ident = ev[1].ident = fd;
	ev[0].flags = ev[1].flags = EV_ADD | EV_ENABLE | flags;
	ev[0].udata = ev[1].udata = ctx;
	unsigned int nev = 0;
	if (mask & polling_read)
		ev[nev++].filter = EVFILT_READ;
	if (mask & polling_write)
		ev[nev++].filter = EVFILT_WRITE;
	auto ret = kevent(m_epfd, ev, nev, nullptr, 0, nullptr);
#endif
	return ret == 0 ? 0 : errno;
}

errno_t poll_ctx::del(int fd)
{
#ifdef HAVE_SYS_EPOLL_H
	auto ret = epoll_ctl(m_epfd, EPOLL_CTL_DEL, fd, nullptr);
#elif defined(HAVE_SYS_EVENT_H)
	struct kevent ev[2]{};
	EV_SET(&ev[0], fd, EVFILT_READ, EV_DELETE, 0, 0, nullptr);
	EV_SET(&ev[1], fd, EVFILT_WRITE, EV_DELETE, 0, 0, nullptr);
	auto ret = kevent(m_epfd, ev, std::size(ev), nullptr, 0, nullptr);
#endif
	return ret == 0 ? 0 : errno;
}

int poll_ctx::wait(const struct timespec *timeout, int max_ev)
{
	if (max_ev < 0 || static_cast<size_t>(max_ev) > m_events.size())
		max_ev = m_events.size();
#ifdef HAVE_SYS_EPOLL_H
#ifdef HAVE_EPOLL_PWAIT2
	return epoll_pwait2(m_epfd, m_events.data(), max_ev, timeout, nullptr);
#else
	int ms = -1; /* -1 = epoll_wait's "block indefinitely" */
	if (timeout != nullptr)
		ms = timeout->tv_sec * 1000 + timeout->tv_nsec / 1000000;
	return epoll_wait(m_epfd, m_events.data(), max_ev, ms);
#endif
#elif defined(HAVE_SYS_EVENT_H)
	return kevent(m_epfd, nullptr, 0, m_events.data(), max_ev, timeout);
#endif
}

void *poll_ctx::data(unsigned int idx) const
{
#ifdef HAVE_SYS_EPOLL_H
	return idx < m_events.size() ? m_events[idx].data.ptr : nullptr;
#elif defined(HAVE_SYS_EVENT_H)
	return idx < m_events.size() ? m_events[idx].udata : nullptr;
#endif
}

void listener_ctx::reset()
{
	watch_stop();
	for (auto &e : m_sockets)
		close(e.fd);
	m_sockets.clear();
}

/**
 * @mark: an integer the caller can use to later recognize certain sockets again
 *        (e.g. unencrypted vs. Implicit TLS)
 */
errno_t listener_ctx::add_inet(const char *addr, uint16_t port, uint32_t mark)
{
	auto fd = HX_inet_listen(addr, port);
	if (fd < 0) {
		auto se = errno;
		mlog(LV_ERR, "%s([%s]:%hu): %s", __PRETTY_FUNCTION__, addr, port, strerror(se));
		return se;
	}
	try {
		m_sockets.emplace_back(fd, mark);
	} catch (const std::bad_alloc &) {
		close(fd);
		mlog(LV_ERR, "%s: ENOMEM", __PRETTY_FUNCTION__);
		return ENOMEM;
	}
	gx_reexec_record(fd);
	return 0;
}

errno_t listener_ctx::add_local(const char *path, uint32_t mark)
{
	auto fd = HX_local_listen(path);
	if (fd < 0) {
		auto se = errno;
		mlog(LV_ERR, "%s(%s): %s", __PRETTY_FUNCTION__, path, strerror(se));
		return se;
	}
	try {
		m_sockets.emplace_back(fd, mark);
	} catch (const std::bad_alloc &) {
		close(fd);
		mlog(LV_ERR, "%s: ENOMEM", __PRETTY_FUNCTION__);
		return ENOMEM;
	}
	gx_reexec_record(fd);
	return 0;
}

errno_t listener_ctx::add_bunch(const char *line, uint32_t mark)
{
	for (auto &&spec : gx_split_ws(line)) {
		if (strncmp(spec.c_str(), "unix:", 5) == 0) {
			auto err = add_local(&spec[5]);
			if (err != 0)
				return err;
			continue;
		}
		std::string host;
		host.resize(spec.size());
		uint16_t port = 0;
		auto ret = HX_addrport_split(spec.c_str(), host.data(), host.size(), &port);
		if (ret != 2) {
			mlog(LV_ERR, "%s: syntax near \"%s\": need both host and port",
				__PRETTY_FUNCTION__, spec.c_str());
			return EINVAL;
		}
		host.resize(strlen(host.data()));
		auto err = add_inet(host.c_str(), port, mark);
		if (err != 0)
			return err;
	}
	return 0;
}

/**
 * Wait on sockets and invoke a callback on new incoming connections.
 *
 * @stop: an extern variable to also evaluate when to stop accepting
 * @cb:   callback when a connection has been accept()ed
 *
 * @cb shall return 0 if processing should continue normally. Any other value
 * causes loop_fptr to return with that value. This way, @cb too can induce a
 * temporary exit from the loop.
 *
 * loop_f returns 0 when stopping normally, -1 on error, and otherwise whatever
 * @cb returned.
 *
 * NOTE: Because the signal handler for e.g. SIGINT may run in a completely
 * unrelated thread, epoll_wait may not get interrupted at all. For this
 * reason, most main() functions have a sleeping loop that evaluates @stop and
 * then specifically pthread_kill()s any children [such as listener_thread],
 * which then also stops epoll_wait.
 */
void *listener_ctx::listener_thread(void *thread_arg)
{
	auto &lctx = *static_cast<listener_ctx *>(thread_arg);
	if (lctx.m_thread_name.size() > 0)
		pthread_setname_np(pthread_self(), lctx.m_thread_name.c_str());

	while (!*lctx.m_stop) {
		auto ready = lctx.m_poller.wait();
		if (ready < 0) {
			if (errno == EINTR)
				continue;
			return nullptr;
		}
		for (int i = 0; i < ready; ++i) {
			auto sd = static_cast<socket_desc *>(lctx.m_poller.data(i));
			assert(sd != nullptr);
			auto conn = generic_connection::accept(sd->fd, lctx.m_haproxy_level, lctx.m_stop);
			if (conn.sockd == -2)
				return 0; /* stop signalled */
			if (conn.sockd < 0)
				continue;
			conn.mark = sd->mark;
			lctx.m_callback(std::move(conn));
		}
	}
	return nullptr;
}

errno_t listener_ctx::watch_start(gromox::atomic_bool &stop,
    int (*cb)(generic_connection &&)) try
{
	watch_stop();
	if (m_sockets.size() == 0)
		return 0;
	m_stop = &stop;
	m_callback = cb;
	auto err = m_poller.init(m_sockets.size());
	if (err != 0)
		return err;
	for (auto &entry : m_sockets) {
		err = m_poller.add(poll_ctx::polling_read | poll_ctx::level_trigger,
		      entry.fd, &entry);
		if (err != 0) {
			m_poller.reset();
			return err;
		}
	}
	auto ret = pthread_create4(&m_thr_id, nullptr, listener_thread, this);
	if (ret != 0) {
		m_poller.reset();
		mlog(LV_ERR, "%s: pthread_create: %s", __PRETTY_FUNCTION__, strerror(ret));
		return ret;
	}
	return 0;
} catch (const std::bad_alloc &) {
	mlog(LV_ERR, "%s: ENOMEM", __PRETTY_FUNCTION__);
	return ENOMEM;
}

void listener_ctx::watch_stop()
{
	if (!pthread_equal(m_thr_id, {})) {
		pthread_kill(m_thr_id, SIGALRM);
		pthread_join(m_thr_id, nullptr);
		m_thr_id = {};
	}
	m_poller.reset();
}

int haproxy_intervene(int fd, unsigned int level, struct sockaddr_storage *ss)
{
	if (level == 0)
		return 0;
	if (level != 2)
		return -1;
	static constexpr uint8_t sig[12] = {0xd, 0xa, 0xd, 0xa, 0x0, 0xd, 0xa, 0x51, 0x55, 0x49, 0x54, 0xa};
	uint8_t buf[4096];
	if (HXio_fullread(fd, buf, 16) != 16)
		return -1;
	if (memcmp(buf, sig, sizeof(sig)) != 0)
		return -1;
	if (static_cast<unsigned int>((buf[12] & 0xF0) >> 4) != level || level != 2)
		return -1;
	if ((buf[12] & 0xF) == 0)
		return 0;
	if ((buf[12] & 0xF) != 1)
		return -1;
	uint16_t hlen = static_cast<uint16_t>(buf[14] << 8) | buf[15];
	switch (buf[13] & 0xF0) {
	case 0x10: {
		if (hlen != 12 || HXio_fullread(fd, buf, 12) != 12)
			return -1;
		auto peer = reinterpret_cast<sockaddr_in *>(ss);
		*peer = {};
		peer->sin_family = AF_INET;
		memcpy(&peer->sin_addr, &buf[0], sizeof(peer->sin_addr));
		memcpy(&peer->sin_port, &buf[8], sizeof(peer->sin_port));
		static_assert(sizeof(peer->sin_addr) == 4 && sizeof(peer->sin_port) == 2);
		return 0;
	}
	case 0x20: {
		if (hlen != 36 || HXio_fullread(fd, buf, 36) != 36)
			return -1;
		auto peer = reinterpret_cast<sockaddr_in6 *>(ss);
		*peer = {};
		peer->sin6_family = AF_INET6;
		memcpy(&peer->sin6_addr, &buf[0], sizeof(peer->sin6_addr));
		memcpy(&peer->sin6_port, &buf[32], sizeof(peer->sin6_port));
		static_assert(sizeof(peer->sin6_addr) == 16 && sizeof(peer->sin6_port) == 2);
		return 0;
	}
	case 0x30: {
		if (hlen != 216 || HXio_fullread(fd, buf, 216) != 216)
			return -1;
		auto peer = reinterpret_cast<sockaddr_un *>(ss);
		*peer = {};
		peer->sun_family = AF_LOCAL;
		memcpy(&peer->sun_path, &buf[0], std::min(static_cast<size_t>(108), sizeof(peer->sun_path)));
		return 0;
	}
	default:
		while (hlen > 0) {
			auto toread = std::min(static_cast<size_t>(hlen), sizeof(buf));
			auto ret = HXio_fullread(fd, buf, toread);
			if (ret < 0 || static_cast<size_t>(ret) != toread)
				return -1;
			hlen -= toread;
		}
		return 0;
	}
	return -1;
}

/**
 * Returns >0 if the process was started.
 * 0 is not returned.
 * Returns <0 to signal an error. (Negative errno returned. /
 * Global errno itself is not guaranteed to be set.)
 */
int socketpass_worker::start_raw(const char *prog, char **argv)
{
	posix_spawn_file_actions_t fa{};
	auto ret = posix_spawn_file_actions_init(&fa);
	if (ret != 0)
		return -ret;
	auto cl_actions = HX::make_scope_exit([&]() { posix_spawn_file_actions_destroy(&fa); });

	int skfd[2]{-1, -1};
	if (socketpair(AF_UNIX, SOCK_SEQPACKET | SOCK_CLOEXEC, 0, skfd) != 0)
		return -errno;
	auto cl_pair = HX::make_scope_exit([&]() {
		if (skfd[0] >= 0)
			close(skfd[0]);
		if (skfd[1] >= 0)
			close(skfd[1]);
	});

	ret = posix_spawn_file_actions_addclose(&fa, skfd[1]);
	if (ret != 0)
		return -ret;
	if (skfd[0] != STDIN_FILENO) {
		ret = posix_spawn_file_actions_adddup2(&fa, skfd[0], STDIN_FILENO);
		if (ret != 0)
			return -ret;
		ret = posix_spawn_file_actions_addclose(&fa, skfd[0]);
		if (ret != 0)
			return -ret;
	}

	ret = posix_spawnp(&m_pid, prog, &fa, nullptr, argv, environ);
	if (ret != 0)
		return -ret;
	cl_pair.release();
	close(skfd[0]);
	m_channel = skfd[1];
	return 1;
}

/**
 * Returns >0 if the process was started.
 * Returns 0 if the process was already alive.
 * Returns <0 to signal an error.
 */
int socketpass_worker::start(const char *prog, char **argv)
{
	if (running())
		return 0;
	stop();
	return start_raw(prog, argv);
}

int socketpass_worker::restart(const char *prog, char **argv)
{
	stop();
	return start_raw(prog, argv);
}

/* Definitely terminate the worker (and then cleanup the process) */
void socketpass_worker::stop()
{
	if (m_channel >= 0) {
		close(m_channel);
		m_channel = -1;
	}
	if (m_pid > 0) {
		kill(m_pid, SIGTERM);
		int status = 0;
		waitpid(m_pid, &status, 0);
		m_pid = -1;
	}
}

/* Cleanup the process (if it exited on its own) */
void socketpass_worker::maybe_reap()
{
	if (m_pid <= 0)
		return;
	int status = 0;
	if (waitpid(m_pid, &status, WNOHANG) != m_pid)
		return;
	m_pid = -1;
	if (m_channel >= 0) {
		close(m_channel);
		m_channel = -1;
	}
}

/**
 * Returns an indication whether the subprocess is still considered running
 * after attempting its potential collection.
 */
bool socketpass_worker::running()
{
	if (m_pid < 0)
		return false;
	int status = 0;
	/* 0: still alive, <0: no child, >0: just reaped */
	auto pid = waitpid(m_pid, &status, WNOHANG);
	if (pid == 0)
		return true;
	if (pid < 0)
		return false; /* no child */
	/* just reaped */
	if (WIFEXITED(status) && WEXITSTATUS(status) != 0)
		mlog(LV_NOTICE, "socketpass worker %d terminated with exit status %d",
			m_pid, WEXITSTATUS(status));
	if (WIFSIGNALED(status))
		mlog(LV_NOTICE, "socketpass worker %d terminated by signal %d",
			m_pid, WTERMSIG(status));
	m_pid = -1;
	return false;
}

errno_t socketpass_worker::pass(std::string_view buffer, int fd_pass) const
{
	/*
	 * SEQPACKET sockets have a caveat that the payload can't be overly
	 * large else sendmsg() will return EMSGSIZE. The limit is sufficiently
	 * high (should be somewhere around the SO_SNDBUF/SO_RCVBUF size) that
	 * it won't matter. Only exmdb_callid::{connect, listen_notification}
	 * are emitted (which have dynamic, but sensible sizes), never
	 * exmdb_callid::write_message (irresponsibly large sizes possible).
	 */
	uint32_t pktlen = buffer.size();
	struct iovec iov;
	iov.iov_base = deconst(buffer.data());
	iov.iov_len  = pktlen;
	alignas(struct cmsghdr) char cbuf[CMSG_SPACE(sizeof(fd_pass))];
	struct msghdr msg{};
	msg.msg_iov        = &iov;
	msg.msg_iovlen     = 1;
	msg.msg_control    = cbuf;
	msg.msg_controllen = std::size(cbuf);
	auto cmsg        = CMSG_FIRSTHDR(&msg);
	cmsg->cmsg_level = SOL_SOCKET;
	cmsg->cmsg_type  = SCM_RIGHTS;
	cmsg->cmsg_len   = CMSG_LEN(sizeof(fd_pass));
	memcpy(CMSG_DATA(cmsg), &fd_pass, sizeof(fd_pass));
	if (sendmsg(m_channel, &msg, MSG_NOSIGNAL) < 0)
		return errno;
	return 0;
}

/**
 * @channel:   AF_UNIX control channel
 * @pkt:       replay of the first packet (e.g. a CONNECT or LISTEN_NOTIFICATION)
 * @client_fd: the client file descriptor
 *
 * Returns a value such that the caller can treat socketpass_receive() similar
 * to as if it were a single syscall. In case of error, client_fd will not be
 * touched.
 *
 * Long, malformed, and proper packets all trigger a return value of 0, and the
 * caller needs to inspect @client_fd and @pkt to know more.
 */
errno_t socketpass_receive(int channel, std::string &pkt, int &client_fd) try
{
	/*
	 * 4K should be enough for exmdb_callid::connect/listen_notification.
	 * If not, something is wrong with the system or the design. (SQL
	 * users.homedir is just 128 chars, and the remote_id should not occupy
	 * much more either.)
	 */
	pkt.resize(4096);

	struct iovec iov;
	iov.iov_base    = pkt.data();
	iov.iov_len     = pkt.size();
	char cbuf[CMSG_SPACE(sizeof(int))]{};
	struct msghdr msg{};
	msg.msg_iov        = &iov;
	msg.msg_iovlen     = 1;
	msg.msg_control    = cbuf;
	msg.msg_controllen = std::size(cbuf);

	client_fd = -1;
	auto read_len = recvmsg(channel, &msg, 0);
	if (read_len < 0) {
		if (errno == EINTR || errno == EAGAIN)
			/* give higher-up frames a chance to reevaluate their loop conditions */
			return 0;
		errno_t se = errno;
		mlog(LV_ERR, "%s: recvmsg: %s", __func__, strerror(se));
		return se;
	}
	if (read_len == 0)
		return ENOENT; /* eof on socket */

	wrapfd received_fd;
	for (auto cmsg = CMSG_FIRSTHDR(&msg); cmsg != nullptr;
	     cmsg = CMSG_NXTHDR(&msg, cmsg)) {
		if (cmsg->cmsg_level != SOL_SOCKET ||
		    cmsg->cmsg_type != SCM_RIGHTS ||
		    cmsg->cmsg_len != CMSG_LEN(sizeof(client_fd)))
			continue;
		int fd = -1;
		memcpy(&fd, CMSG_DATA(cmsg), sizeof(fd));
		received_fd = wrapfd(fd);
		/*
		 * Keep looping, we need to process all control messages.
		 * Just on the odd chance someone is sending more than one fd.
		 * (The use of wrapfd ensures all the unused ones get closed.)
		 */
	}
	/* This needs to be evaluated after fds have been placed into wrapfd */
	if (msg.msg_flags & (MSG_TRUNC | MSG_CTRUNC)) {
		mlog(LV_ERR, "%s: recvmsg: ignoring seqpacket larger than our buffer", __func__);
		pkt.clear();
		return 0;
	}
	if (received_fd.get() < 0) {
		pkt.clear();
		return 0; /* No fd received */
	}
	pkt.resize(read_len);
	client_fd = received_fd.release();
	return 0;
} catch (const std::bad_alloc &) {
	mlog(LV_ERR, "%s: ENOMEM", __func__);
	return ENOMEM;
}

workqueue::~workqueue()
{
	if (this == &global_workqueue && !m_tasklist.empty())
		mlog(LV_WARN, "%s: global_wq ought to be empty at global destruction, but it's not: \"%s\"",
			__func__, m_tasklist.front().name);
	stop();
}

void workqueue::stop()
{
	if (pthread_equal(m_thrid, {}))
		return;
	m_stop = true;
	m_cv.notify_one();
	pthread_join(m_thrid, nullptr);
	m_thrid = {};
}

void workqueue::mainloop()
{
	while (!m_stop) {
		/* Wait until the right time */
		std::unique_lock lk(m_tasklock);
		if (m_tasklist.empty()) {
			m_cv.wait(lk, [this]() { return m_stop || m_tasklist.size() > 0; });
		} else {
			auto ut = m_tasklist.front().start_time;
			m_cv.wait_until(lk, ut);
		}

		if (m_stop)
			break;
		if (m_tasklist.empty())
			continue; /* Task got deleted while we slept */
		auto now = tp_now();
		auto tsk = m_tasklist.begin();
		if (now < tsk->start_time)
			continue; /* Not ready yet */

		/*
		 * tsk is going invalid with lk.unlock. Move important parts to
		 * the local scope. The task must stay in the list though, so
		 * the duplicate name check still works.
		 */
		auto func   = std::move(tsk->func);
		auto obj    = std::move(tsk->obj);
		auto period = tsk->period;
		auto name   = tsk->name;

		/* Execute this task now */
		lk.unlock();
		try {
			func(obj);
		} catch (const std::bad_any_cast &) {
			mlog(LV_ERR, "%s: Uncaught std::bad_any_cast in wq task %s", __func__, name);
		} catch (...) {
#ifdef __GNUC__
			auto ti = __cxxabiv1::__cxa_current_exception_type();
			mlog(LV_ERR, "%s: Uncaught exception %s in task %s",
				__func__, ti->name(), name);
#else
			mlog(LV_ERR, "%s: Uncaught exception in task %s", __func__, name);
#endif
		}
		if (period == time_duration{}) {
			/* That was a run-once task */
			delete_task(name);
#ifdef COVERITY
			/* <https://github.com/llvm/llvm-project/issues/204304> */
			lk.lock();
#endif
			continue;
		}

		auto next_time = tp_now() + period;
		lk.lock();
		/*
		 * Position in vector may have changed, so a re-lookup is needed.
		 * Comparing the name by pointer value is sufficient.
		 */
		tsk = std::find_if(m_tasklist.begin(), m_tasklist.end(),
		      [&](const task &t) { return t.name == name; });
		if (tsk == m_tasklist.end())
			continue;
		auto ip = std::upper_bound(m_tasklist.begin(),
		          m_tasklist.end(), next_time,
		          [](time_point p, const task &t) { return p < t.start_time; });
		if (tsk < ip)
			std::rotate(tsk, tsk + 1, ip);
		else
			std::rotate(ip, tsk, tsk + 1);
		tsk->start_time = std::move(next_time);
		tsk->func = std::move(func);
		tsk->obj = std::move(obj);
	}
}

errno_t workqueue::launch_ondemand()
{
	std::unique_lock lk(m_thrlock);
	if (!pthread_equal(m_thrid, {}))
		return 0; /* already running */

	auto raw_entry = [](void *arg) -> void * {
		pthread_setname_np(pthread_self(), "gl_workqueue");
		static_cast<workqueue *>(arg)->mainloop();
		return nullptr;
	};
	auto err = pthread_create(&m_thrid, nullptr, raw_entry, this);
	if (err == 0)
		return 0;
	mlog(LV_ERR, "workqueue::launch: pthread_create: %s", strerror(err));
	return err;
}

bool workqueue::task_exists(const char *name) const
{
	return std::any_of(m_tasklist.cbegin(), m_tasklist.cend(),
	       [&](const struct task &task) { return strcmp(task.name, name) == 0; });
}

void workqueue::delete_task(const char *name)
{
	bool empty = false;
	{
		std::unique_lock lk(m_tasklock);
		std::erase_if(m_tasklist, [&](const struct task &task) {
			return strcmp(task.name, name) == 0;
		});
		empty = m_tasklist.empty();
	}
	if (empty)
		stop();
}

errno_t workqueue::insert_task(const char *name, std::chrono::nanoseconds period,
    void (*func)(std::any &), std::any &&obj)
{
	auto start_time = tp_now();

	{
		std::unique_lock lk(m_tasklock);
		if (task_exists(name))
			return EEXIST;
		auto here = std::upper_bound(m_tasklist.begin(), m_tasklist.end(),
		            start_time,
		            [](time_point tp, const struct workqueue::task &task) {
		            	return tp < task.start_time;
		            });	
		m_tasklist.emplace(here, start_time, period, std::move(obj), func, name);
		m_cv.notify_one();
	}
	return launch_ondemand();
}

} /* namespace gromox */

generic_connection::generic_connection(generic_connection &&o) :
	client_port(o.client_port), server_port(o.server_port),
	proxy_port(o.proxy_port),
	sockd(std::move(o.sockd)), mark(std::move(o.mark)), ssl(std::move(o.ssl)),
	last_timestamp(o.last_timestamp)
{
	memcpy(client_addr, o.client_addr, sizeof(client_addr));
	memcpy(server_addr, o.server_addr, sizeof(server_addr));
	memcpy(proxy_addr, o.proxy_addr, sizeof(proxy_addr));
	o.sockd = -1;
	o.ssl = nullptr;
}

generic_connection &generic_connection::operator=(generic_connection &&o)
{
	if (this == &o)
		return *this;
	reset();
	memcpy(client_addr, o.client_addr, sizeof(client_addr));
	memcpy(server_addr, o.server_addr, sizeof(server_addr));
	memcpy(proxy_addr, o.proxy_addr, sizeof(proxy_addr));
	client_port = o.client_port;
	server_port = o.server_port;
	proxy_port = o.proxy_port;
	sockd = std::move(o.sockd);
	o.sockd = -1;
	mark = std::move(o.mark);
	ssl = std::move(o.ssl);
	o.ssl = nullptr;
	last_timestamp = o.last_timestamp;
	return *this;
}

generic_connection generic_connection::takeover(int cl_sock)
{
	generic_connection conn;
	conn.sockd = std::move(cl_sock);
	struct sockaddr_storage sv_addr, cl_addr;
	socklen_t addrlen = sizeof(cl_addr);
	auto ret = getpeername(conn.sockd, reinterpret_cast<sockaddr *>(&cl_addr),
	           &addrlen);
	if (ret != 0) {
		mlog(LV_WARN, "getpeername: %s\n", gai_strerror(ret));
		conn.reset();
		return conn;
	}
	/* no call to haproxy — the socket may already be through all those init stages */

	char txtport[40];
	ret = getnameinfo(reinterpret_cast<sockaddr *>(&cl_addr), addrlen,
	      conn.client_addr, sizeof(conn.client_addr), txtport,
	      sizeof(txtport), NI_NUMERICHOST | NI_NUMERICSERV);
	if (ret != 0) {
		mlog(LV_WARN, "getnameinfo: %s\n", gai_strerror(ret));
		conn.reset();
		return conn;
	}
	conn.client_port = strtoul(txtport, nullptr, 0);
	addrlen = sizeof(sv_addr);
	ret = getsockname(conn.sockd, reinterpret_cast<sockaddr *>(&sv_addr), &addrlen);
	if (ret != 0) {
		mlog(LV_WARN, "getsockname: %s\n", strerror(errno));
		conn.reset();
		return conn;
	}
	ret = getnameinfo(reinterpret_cast<sockaddr *>(&sv_addr), addrlen,
	      conn.server_addr, sizeof(conn.server_addr), txtport,
	      sizeof(txtport), NI_NUMERICHOST | NI_NUMERICSERV);
	if (ret != 0) {
		mlog(LV_WARN, "getnameinfo: %s\n", gai_strerror(ret));
		conn.reset();
		return conn;
	}
	conn.server_port = strtoul(txtport, nullptr, 0);
	conn.last_timestamp = tp_now();
	return conn;
}

generic_connection generic_connection::accept(int sv_sock,
    int haproxy, gromox::atomic_bool *stop_accept)
{
	generic_connection conn;
	struct sockaddr_storage sv_addr, cl_addr;
	socklen_t addrlen = sizeof(cl_addr);
	auto cl_sock = accept4(sv_sock, reinterpret_cast<struct sockaddr *>(&cl_addr),
	               &addrlen, SOCK_CLOEXEC);
	conn.sockd = cl_sock;
	if (*stop_accept) {
		conn.reset();
		conn.sockd = -2;
		return conn;
	} else if (cl_sock < 0) {
		conn.reset();
		return conn;
	}
	if (haproxy_intervene(cl_sock, haproxy, &cl_addr) < 0) {
		conn.reset();
		return conn;
	}
	char txtport[40];
	auto ret = getnameinfo(reinterpret_cast<sockaddr *>(&cl_addr), addrlen,
		   conn.client_addr, sizeof(conn.client_addr), txtport,
		   sizeof(txtport), NI_NUMERICHOST | NI_NUMERICSERV);
	if (ret != 0) {
		mlog(LV_WARN, "getnameinfo: %s\n", gai_strerror(ret));
		conn.reset();
		return conn;
	}
	conn.client_port = strtoul(txtport, nullptr, 0);
	addrlen = sizeof(sv_addr);
	ret = getsockname(cl_sock, reinterpret_cast<sockaddr *>(&sv_addr), &addrlen);
	if (ret != 0) {
		mlog(LV_WARN, "getsockname: %s\n", strerror(errno));
		conn.reset();
		return conn;
	}
	ret = getnameinfo(reinterpret_cast<sockaddr *>(&sv_addr), addrlen,
	      conn.server_addr, sizeof(conn.server_addr), txtport,
	      sizeof(txtport), NI_NUMERICHOST | NI_NUMERICSERV);
	if (ret != 0) {
		mlog(LV_WARN, "getnameinfo: %s\n", gai_strerror(ret));
		conn.reset();
		return conn;
	}
	conn.server_port = strtoul(txtport, nullptr, 0);
	conn.last_timestamp = tp_now();
	return conn;
}
