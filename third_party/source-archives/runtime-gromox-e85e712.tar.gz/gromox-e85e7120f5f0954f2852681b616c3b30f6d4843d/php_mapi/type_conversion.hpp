#pragma once
#include "php.h"
#undef slprintf
#undef vslprintf
#undef snprintf
#undef vsnprintf
#undef vasprintf
#undef asprintf
#include <cstdint>
#include <optional>
#include <vector>

namespace gromox {
using proptag_t = std::uint32_t;
}
extern gromox::proptag_t proptag_to_phptag(gromox::proptag_t);
extern gromox::proptag_t phptag_to_proptag(gromox::proptag_t);
extern ec_error_t php_to_binary_array(zval *, BINARY_ARRAY *);
extern ec_error_t binary_array_to_php(const BINARY_ARRAY &, zval *);
extern ec_error_t php_to_sortorder_set(zval *, SORTORDER_SET *);
extern ec_error_t php_to_proptag_array(zval *, PROPTAG_ARRAY *);
extern ec_error_t php_to_proptag_array(zval *, std::vector<gromox::proptag_t> &);
extern ec_error_t php_to_proptag_array(zval *, std::optional<std::vector<gromox::proptag_t>> &);
extern ec_error_t php_to_tpropval_array(zval *, TPROPVAL_ARRAY *);
extern ec_error_t php_to_tarray_set(zval *, TARRAY_SET *);
extern ec_error_t php_to_rule_list(zval *, RULE_LIST *);
extern ec_error_t php_to_restriction(zval *pzval, RESTRICTION *);
extern ec_error_t restriction_to_php(const RESTRICTION &, zval *);
extern ec_error_t proptag_array_to_php(const PROPTAG_ARRAY &, zval *);
extern ec_error_t tpropval_array_to_php(const TPROPVAL_ARRAY &, zval *);
extern ec_error_t tarray_set_to_php(const TARRAY_SET &, zval *);
extern ec_error_t state_array_to_php(const STATE_ARRAY &, zval *);
extern ec_error_t php_to_state_array(zval *, STATE_ARRAY *);
extern ec_error_t znotification_array_to_php(const ZNOTIFICATION_ARRAY &, zval *);
extern ec_error_t php_to_propname_array(zval *names, zval *guids, PROPNAME_ARRAY *);
extern ec_error_t fb_array_to_php(const std::vector<freebusy_event> &, zval *);

/* Wrap this so cov-scan only complains once (hopefully) */
static inline void zarray_init(zval *x)
{
	array_init(x);
}
